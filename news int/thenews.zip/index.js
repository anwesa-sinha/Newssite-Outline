function openNav() {
    document.getElementById("dash").style.width = "350px";
  }
  
  /* Set the width of the sidebar to 0 (hide it) */
  function closeNav() {
    document.getElementById("dash").style.width = "0";
  }

